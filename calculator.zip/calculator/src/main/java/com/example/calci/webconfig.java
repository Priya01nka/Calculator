package com.example.calci;

	import org.springframework.context.annotation.Configuration;
	import org.springframework.web.servlet.config.annotation.*;

	@Configuration
	public class webconfig implements WebMvcConfigurer {
	    @Override
	    public void addCorsMappings(CorsRegistry registry) {
	        registry.addMapping("/api/**")
	                .allowedOrigins("http://localhost:8080") // change if you serve frontend on different origin
	                .allowedMethods("GET", "POST", "OPTIONS")
	                .allowedHeaders("*");
	    }
	}
