package com.example.calci;


	import org.springframework.http.ResponseEntity;
	import org.springframework.web.bind.annotation.*;

	import java.util.Map;

	@RestController
	@RequestMapping("/api")
	public class contr {

	    @GetMapping("/add")
	    public ResponseEntity<Map<String,Object>> add(@RequestParam double num1, @RequestParam double num2) {
	        return ResponseEntity.ok(Map.of("result", num1 + num2));
	    }

	    @GetMapping("/subtract")
	    public ResponseEntity<Map<String,Object>> subtract(@RequestParam double num1, @RequestParam double num2) {
	        return ResponseEntity.ok(Map.of("result", num1 - num2));
	    }

	    @GetMapping("/multiply")
	    public ResponseEntity<Map<String,Object>> multiply(@RequestParam double num1, @RequestParam double num2) {
	        return ResponseEntity.ok(Map.of("result", num1 * num2));
	    }

	    @GetMapping("/divide")
	    public ResponseEntity<Map<String,Object>> divide(@RequestParam double num1, @RequestParam double num2) {
	        if (num2 == 0) {
	            return ResponseEntity
	                    .badRequest()
	                    .body(Map.of("error", "Division by zero is not allowed"));
	        }
	        return ResponseEntity.ok(Map.of("result", num1 / num2));
	    }
	}

