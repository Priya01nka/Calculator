const display = document.getElementById('display');

let currentInput = '0';
let previousInput = null; // store as number
let operator = null;
let waitingForSecondOperand = false;

function updateDisplay() {
    display.value = currentInput;
}

function clearAll() {
    currentInput = '0';
    previousInput = null;
    operator = null;
    waitingForSecondOperand = false;
    updateDisplay();
}

function handleNumber(number) {
    if (waitingForSecondOperand) {
        currentInput = number;
        waitingForSecondOperand = false;
    } else {
        currentInput = currentInput === '0' ? number : currentInput + number;
    }
    updateDisplay();
}

function handleOperator(nextOperator) {
    const inputValue = parseFloat(currentInput);
    if (operator && waitingForSecondOperand) {
        // change operator before second operand entered
        operator = nextOperator;
        return;
    }

    if (previousInput === null) {
        previousInput = inputValue;
    } else if (operator) {
        // compute intermediate result locally (optional) or call backend
        // We'll call backend when user hits '=' for consistent behavior.
    }

    operator = nextOperator;
    waitingForSecondOperand = true;
}

function handleDecimal() {
    if (!currentInput.includes('.')) {
        currentInput += '.';
        updateDisplay();
    }
}

async function performCalculation(secondOperand) {
    if (operator === null || previousInput === null) return;

    let endpoint;
    switch (operator) {
        case '+': endpoint = 'add'; break;
        case '-': endpoint = 'subtract'; break;
        case '*': endpoint = 'multiply'; break;
        case '/': endpoint = 'divide'; break;
        default: return;
    }

    // API URL (backend on port 8080)
    const url = `http://localhost:8080/api/${endpoint}?num1=${previousInput}&num2=${secondOperand}`;

    try {
        const response = await fetch(url);
        const data = await response.json();

        if (!response.ok) {
            currentInput = data?.error || 'Error';
        } else {
            // numeric result -> convert to string, remove trailing zeros if needed
            currentInput = String(data.result);
            // update previousInput so user can continue calculations
            previousInput = parseFloat(currentInput);
        }

        operator = null;
        waitingForSecondOperand = true;
        updateDisplay();
    } catch (err) {
        console.error('Fetch error:', err);
        currentInput = 'Network Error';
        updateDisplay();
    }
}

/* Event handling */
document.querySelector('.calculator-grid').addEventListener('click', (event) => {
    const { target } = event;
    if (!target.matches('button')) return;

    if (target.classList.contains('clear-all')) {
        clearAll();
        return;
    }

    if (target.classList.contains('operator')) {
        handleOperator(target.innerText);
        return;
    }

    if (target.classList.contains('equals')) {
        // Trigger calculation using currentInput as second operand
        performCalculation(parseFloat(currentInput));
        return;
    }

    if (target.classList.contains('decimal')) {
        handleDecimal();
        return;
    }

    if (target.classList.contains('number')) {
        handleNumber(target.innerText);
        return;
    }
});

/* initialize */
updateDisplay();
